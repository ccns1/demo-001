var RTCMultiConnection = function(roomid, forceOptions) {
